package rainpole;
use Dancer ':syntax';
use Sys::Hostname;
use IO::Socket::INET;

set port => 8080;
set daemon => true;

our $VERSION = '0.1';

get '/' => sub {
    my ($hostname) = hostname;
    my ($sql_status);
    my ($socket) = IO::Socket::INET->new(Proto=>"tcp", PeerAddr => "192.168.3.10", PeerPort => "3306", Timeout => 2);

    if ($@) { $sql_status = "Database connection failed" } else { $sql_status = "Database connection successfull"}

    template 'index', { hostname => $hostname, sql_status => $sql_status };
};

get '/company' => sub {
    my ($hostname) = hostname;
    my ($sql_status);
    my ($socket) = IO::Socket::INET->new(Proto=>"tcp", PeerAddr => "192.168.3.10", PeerPort => "3306", Timeout => 2);
    
    if ($@) { $sql_status = "Database connection failed" } else { $sql_status = "Database connection successfull"}

    template 'company', { hostname => $hostname, sql_status => $sql_status };
};

any qr{.*} => sub {
    my ($hostname) = hostname;
    my ($sql_status);

    $sql_status = "Database connection untested";

    template 'lab', { hostname => $hostname, sql_status => $sql_status }; 
};

true;
